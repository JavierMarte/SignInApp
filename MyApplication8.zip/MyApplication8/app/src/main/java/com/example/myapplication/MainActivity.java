package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void enter(View view) {

        //Intent i = new Intent(this, collection.class);
        //startActivity(i);



        Firebase.setAndroidContext(this);

        Firebase myFirebaseRef = new Firebase("https://tracker-97afc.firebaseio.com/");
        //https://churchacunit.firebaseio.com/

        myFirebaseRef.child("message").setValue("Do you have data? You'll love Firebase.");


        /*
        myFirebaseRef.child("churchacunit").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                System.out.println(dataSnapshot.getValue());  //prints "Do you have data? You'll love Firebase."
               // Log.writeToLogFile(""+ dataSnapshot.getValue());
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }

//            @Override
//            public void onDataChange(DataSnapshot snapshot) {
//                System.out.println(snapshot.getValue());  //prints "Do you have data? You'll love Firebase."
//            }
//            @Override public void onCancelled(FirebaseError error) { }
        });

        */

    }

}
